from .start import dp
from .rassilka import dp, telegraph
from .help import dp
from .echo import dp

__all__ = ["dp", "telegraph"]
