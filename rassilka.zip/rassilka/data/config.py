import os

from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = str(os.getenv("BOT_TOKEN"))
admins = [
    os.getenv("ADMIN_ID_1"),
    os.getenv("ADMIN_ID_2"),
]

