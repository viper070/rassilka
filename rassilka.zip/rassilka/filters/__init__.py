from aiogram import Dispatcher


def setup(dp: Dispatcher):
    pass
